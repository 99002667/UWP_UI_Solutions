﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Bezier_Curve_UI
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void MySlider1_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            MyCurve1.Point2 = new Point(150, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve1.Point1 = new Point(50, 1 * (Convert.ToDouble(e.NewValue)));
            Curve2.StartPoint = new Point(150, 1 * (Convert.ToDouble(e.NewValue)));
        }

        private void MySlider2_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
           
            Curve3.StartPoint = new Point(300, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve3.Point1 = new Point(350, 1 * ((Convert.ToDouble(e.NewValue)) + 10));

            MyCurve2.Point3 = new Point(300, 1 * (Convert.ToDouble(e.NewValue)));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve2.Point2 = new Point(250, (1 * (Convert.ToDouble(e.NewValue))) - 10);
                MyCurve2.Point1 = new Point(240, -1 * ((Convert.ToDouble(e.NewValue)) - 250));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250) {
                MyCurve2.Point2 = new Point(250, 250);
                MyCurve2.Point1 = new Point(240, 250);
            }   
        }

        private void MySlider3_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            MyCurve3.Point3 = new Point(450, 1 * (Convert.ToDouble(e.NewValue)));
            Curve4.StartPoint = new Point(450, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve4.Point1= new Point(500, 1 * ((Convert.ToDouble(e.NewValue))));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve3.Point2 = new Point(400, 1 * (Convert.ToDouble(e.NewValue)));
            
            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve3.Point2 = new Point(400, 250);
                MyCurve3.Point1 = new Point(350, 250);
            }

        }

        private void MySlider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            //MyCurve4.Point3 = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
            //MyCurve4.Point2 = new Point(500, 1 * ((Convert.ToDouble(e.NewValue))-10));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve4.Point3 = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
                MyCurve4.Point2 = new Point(500, 1 * ((Convert.ToDouble(e.NewValue)) - 10));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve4.Point3 = new Point(600, 250);
                MyCurve4.Point2 = new Point(500,250);
            }

            Curve5.StartPoint = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve5.Point1 = new Point(660, 1 * (Convert.ToDouble(e.NewValue)));


        }

        private void MySlider5_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve5.Point2 = new Point(700, 1 * ((Convert.ToDouble(e.NewValue)) + 10));
                MyCurve5.Point3 = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve5.Point2 = new Point(700, 250);
                MyCurve5.Point3 = new Point(750, 250);
            }
            //MyCurve5.Point2 = new Point(700, 1 * ((Convert.ToDouble(e.NewValue))+10));
            //MyCurve5.Point3 = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve6.Point1 = new Point(810, 1 * (Convert.ToDouble(e.NewValue)));
            Curve6.StartPoint = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));
        }

    }
}
