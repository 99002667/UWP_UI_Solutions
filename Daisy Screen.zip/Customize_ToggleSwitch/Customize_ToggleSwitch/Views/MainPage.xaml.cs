﻿using Customize_ToggleSwitch.ViewModel;
using Customize_ToggleSwitch.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Customize_ToggleSwitch
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        ObservableCollection<Listview2details> _reference;
        
        public MainPage()
        {
            this.InitializeComponent();
            _reference = GetData_list();      
            Source.ItemsSource = _reference;
        }

        private void Enter_Clicked(object sender, RoutedEventArgs e)
        {
            string list_Name = Createchain_txt.Text;
            _reference.Add(new Listview2details() { Title = list_Name });


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(TeamRed));


        }

        private void ShowPopupOffsetClicked(object sender, RoutedEventArgs e)
        {
            // open the Popup if it isn't open already 
            if (!StandardPopup.IsOpen) { StandardPopup.IsOpen = true; }
        }
        private void ClosePopupClicked(object sender, RoutedEventArgs e)
        {
            // if the Popup is open, then close it 
            if (StandardPopup.IsOpen) { StandardPopup.IsOpen = false; }
        }

        private ObservableCollection<Listview2details> GetData_list()
        {
            return new ObservableCollection<Listview2details>
            {
               new Listview2details() { Title = "Team Red" },
               new Listview2details() { Title = "Team Blue" },
               new Listview2details() { Title = "Chain 3" },
               new Listview2details() { Title = "Chain 4" },

        };

        }

       
    }


    public class Listview2details
        {
        public string Title { get; set; }
        //public string image { get; set; }
        }

    
}
