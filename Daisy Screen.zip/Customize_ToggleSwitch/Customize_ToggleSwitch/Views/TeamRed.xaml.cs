﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Customize_ToggleSwitch.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TeamRed : Page
    {
        

        public TeamRed()
        {
            this.InitializeComponent();
        }

            private void bt1_Click(object sender, RoutedEventArgs e)
            {
            if ((String)btn1.Content == "Mute")
            {
                btn1.Content = "UnMute";
                MyText.Text = "Team Red - UnMute";
                MyText.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
            }
            else {
                btn1.Content = "Mute";
                MyText.Text = "Team Red - Mute";
                MyText.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            }
            
            }

          

        private void bt2_Click(object sender, RoutedEventArgs e)
        {
            if ((String)btn2.Content == "Mute")
            {
                btn2.Content = "UnMute";
                Text2.Text = "Team Red - UnMute";
                Text2.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
            }
            else
            {
                btn2.Content = "Mute";
                Text2.Text = "Team Red - Mute";
                Text2.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            }


        }

        private void bt3_Click(object sender, RoutedEventArgs e)
        {
            if ((String)btn3.Content == "Mute")
            {
                btn3.Content = "UnMute";
                Text3.Text = "Team Red - UnMute";
                Text3.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
            }
            else
            {
                btn3.Content = "Mute";
                Text3.Text = "Team Red - Mute";
                Text3.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            }


        }

        private void leave_Click(object sender, RoutedEventArgs e) {
            this.Frame.Navigate(typeof(MainPage));
        }
        
        private void bt4_Click(object sender, RoutedEventArgs e)
        {
            if ((String)btn4.Content == "Mute")
            {
                btn4.Content = "UnMute";
                Text4.Text = "Team Red - UnMute";
                Text4.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
            }
            else
            {
                btn4.Content = "Mute";
                Text4.Text = "Team Red - Mute";
                Text4.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            }


        }


    }
}
