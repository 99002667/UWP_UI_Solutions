﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Customize_ToggleSwitch.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Flip_View : Page
    {

        public ObservableCollection<flip_View_Items> flipViewData { get; set; }

        public Flip_View()
        {
            this.InitializeComponent();
            flipViewData = new ObservableCollection<flip_View_Items>();
            flipViewData.Add(new flip_View_Items() { Images = "/Assets/Images/Image_5.png",
                                                     Name="SOURCE SELECTION", 
                                                     Text="Your A30 Headset has the ability to connect to three audio sources at one time. You can Connect to other devices using the 3.5mm audio cable, USB-C cable, and Bluetooth."});
            flipViewData.Add(new flip_View_Items() { Images = "/Assets/Images/Image_4.png", 
                                                     Name = "MIXER",
                                                     Text="Select two audio sources from which the mixing sources to balance between them. Adding more volume to one source will decrease the volume of the other source. " });
            flipViewData.Add(new flip_View_Items() { Images = "/Assets/Images/Image_3.png",
                                                     Name = "MICROPHONE",
                                                     Text="The ASTRO A30 Headset has two sets of microphones. The first is the external boom mic, for gaming and chat. The second is an internal mic array. for on-the-go use."});
            flipViewData.Add(new flip_View_Items() {  Images = "/Assets/Images/Image_1.png",
                                                      Name = "MICROPHONE",
                                                      Text = "The ASTRO A30 Headset has two sets of microphones. The first is the external boom mic, for gaming and chat. The second is an internal mic array. for on-the-go use."}); 
            flipViewData.Add(new flip_View_Items() {  Images = "/Assets/Images/Image_2.png", 
                                                      Name = "THUMB STICK",
                                                      Text="When listening to music or other media usig Bluetooth, use the center thumb stick to: press 1x to play or pause, 2x to skip track, and 3x to skip back to previous track"});        
            flipView.ItemsSource = flipViewData;
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            int val = flipView.SelectedIndex;
            if (val == 4)
            {
                Next.Content = "COMPLETE";
                this.Frame.Navigate(typeof(MainPage));
                flipView.SelectedIndex = 0;

            }
            else
            {
                Next.Content = "NEXT";
                flipView.SelectedIndex = val + 1;

            }
        }

        private void Indicator1(object sender, SelectionChangedEventArgs e)
        {
            if (listbox_Indicator.SelectedIndex == 4)
            {
                Next.Content = "COMPLETE";
            }
            else
            {
                Next.Content = "NEXT";
            }
        }
        
        private void Skip_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
            flipView.SelectedIndex = 0;

        }

    }



    public class flip_View_Items { 
    
       public string Images { get; set; }
       public string Name { get; set; }
        public string Text { get; set; }
    }
}
