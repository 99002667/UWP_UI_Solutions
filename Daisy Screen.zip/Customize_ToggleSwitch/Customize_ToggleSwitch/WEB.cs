﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customize_ToggleSwitch.ViewModel
{
    class WEB
    {
        public string webAddress { get; set; }
        public string google = @"http://www.google.com";
        public string facebook = @"http://www.facebook.com";
    }
}
