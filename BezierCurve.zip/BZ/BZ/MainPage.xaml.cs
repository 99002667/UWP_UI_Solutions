﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace BZ
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            //pointAnimation.Begin();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Seg1.Point1 = new Point(Convert.ToDouble(x_p1.Text), Convert.ToDouble(y_p1.Text));
            //Seg1.Point2 = new Point(Convert.ToDouble(x_p2.Text), Convert.ToDouble(y_p2.Text));

        }

        private void slider1_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            Seg1.Point1 = new Point(50, Convert.ToDouble(slider1.Value));
            //Seg1.Point2 = new Point(Convert.ToDouble(x_p2.Text), Convert.ToDouble(y_p2.Text));
        }

        //private void Thumb_DragDelta(object sender, DragDeltaEventArgs e)
        //{

        //}
    }
}
