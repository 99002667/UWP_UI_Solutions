﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Input;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Bezier_Curve_UI
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>

    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
       // int val = h7.GetValue(Y1);

        private void MySlider1_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            MyCurve1.Point2 = new Point(150, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve1.Point1 = new Point(50, 1 * (Convert.ToDouble(e.NewValue)));
            Curve2.StartPoint = new Point(150, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve2.Point1 = new Point(225, 1 * (Convert.ToDouble(e.NewValue)));
            h1.Y2 = 250;
            h2.Y2 = 250;
            h3.Y2 = 250;
            h4.Y2 = 250;
            h5.Y2 = 250;
            h6.Y2 = 250;
            h7.Y2 = 250;
            h8.Y2 = 250;
            h9.Y2 = 250;
            h10.Y2 = 250;
            h11.Y2 = 250;
            h12.Y2 = 250;
            h13.Y2 = 250;
            h14.Y2 = 250;
            
            if ((Convert.ToDouble(e.NewValue)!= 250) && (Convert.ToDouble(e.NewValue) >= 30) && (Convert.ToDouble(e.NewValue) < 250))
            {
                h14.Y1 = (Convert.ToDouble(e.NewValue));
                h13.Y1 = (Convert.ToDouble(e.NewValue)) + 1;
                h12.Y1 = (Convert.ToDouble(e.NewValue)) + 3;
                h11.Y1 = (Convert.ToDouble(e.NewValue)) + 10;
                h10.Y1 = (Convert.ToDouble(e.NewValue)) + 14;
                h9.Y1 = (Convert.ToDouble(e.NewValue)) + 23;
                h8.Y1 = (Convert.ToDouble(e.NewValue)) + 32;
                h7.Y1 = (Convert.ToDouble(e.NewValue)) + 45;
                h6.Y1 = (Convert.ToDouble(e.NewValue)) + 60;
                h5.Y1 = (Convert.ToDouble(e.NewValue)) + 78;
                h4.Y1 = (Convert.ToDouble(e.NewValue)) + 105;
                h3.Y1 = (Convert.ToDouble(e.NewValue)) + 128;
                h2.Y1 = (Convert.ToDouble(e.NewValue)) + 160;

                if ((Convert.ToDouble(e.NewValue) >= 49)){
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 151;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 117;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 93;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 69;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 53;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 43;

                }

                if ((Convert.ToDouble(e.NewValue) >= 71)){
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 138;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 110;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 89;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 66;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 50;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 40;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 30;
                }

                if ((Convert.ToDouble(e.NewValue) >= 80))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 130;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 104;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 84;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 62;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 48;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 36;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 29;
                }

                if ((Convert.ToDouble(e.NewValue) >= 93))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 123;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 98;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 78;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 54;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 42;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 32;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 26;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 20;
                }

                if ((Convert.ToDouble(e.NewValue) >= 104))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 110;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 90;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 70;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 50;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 37;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 28;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 20;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 16;
                }
                if ((Convert.ToDouble(e.NewValue) >= 117))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 105;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 84;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 64;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 46;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 34;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 25;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 17;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 13;
                    h10.Y1 = (Convert.ToDouble(e.NewValue)) + 10;
                    h11.Y1 = (Convert.ToDouble(e.NewValue)) + 8;
                }
                if ((Convert.ToDouble(e.NewValue) >= 129))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 95;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 78;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 58;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 43;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 31;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 25;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 17;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 13;
                    h10.Y1 = (Convert.ToDouble(e.NewValue)) + 10;
                    h11.Y1 = (Convert.ToDouble(e.NewValue)) + 8;
                }

                if ((Convert.ToDouble(e.NewValue) >= 140))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 90;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 72;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 54;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 39;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 28;
                    if ((Convert.ToDouble(e.NewValue) >= 146)) {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) + 84;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) + 68;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) + 50;
                    }
                  
                }

                if ((Convert.ToDouble(e.NewValue) >= 150))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 75;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 61;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 46;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 36;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 28;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 21;
                    h10.Y1 = (Convert.ToDouble(e.NewValue)) + 8;
                    h11.Y1 = (Convert.ToDouble(e.NewValue)) + 6;

                }
                if ((Convert.ToDouble(e.NewValue) >= 164))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 65;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 52;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 41;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 30;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 22;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 15;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 14;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 10;
                    h10.Y1 = (Convert.ToDouble(e.NewValue)) + 6;
                    h11.Y1 = (Convert.ToDouble(e.NewValue)) + 4;

                }

                if ((Convert.ToDouble(e.NewValue) >= 175))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 60;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 48;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 37;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 27;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 22;

                }

                if ((Convert.ToDouble(e.NewValue) >= 182))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 56;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 42;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 33;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 24;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 20;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 11;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 7;
                }
                if ((Convert.ToDouble(e.NewValue) >= 190))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 49;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 37;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 29;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 21;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 18;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 9;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 5;

                    if ((Convert.ToDouble(e.NewValue) >= 196)) {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) + 40;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) + 33;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) + 24;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) + 18;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) + 14;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) + 12;

                        if ((Convert.ToDouble(e.NewValue) >= 205)) {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) + 35;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) + 28;
                            h4.Y1 = (Convert.ToDouble(e.NewValue)) + 20;
                        }
                    }
                }
                if ((Convert.ToDouble(e.NewValue) >= 210))
                {
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) + 30;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) + 21;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) + 17;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) + 12;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) + 10;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) + 8;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) + 8;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) + 4;

                    if ((Convert.ToDouble(e.NewValue) >= 218)) {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) + 25;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) + 18;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) + 12;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) + 4;
                        h10.Y1 = (Convert.ToDouble(e.NewValue)) + 4;
                        h11.Y1 = (Convert.ToDouble(e.NewValue)) + 2;
                    }
                }



                h14.Visibility = Visibility;
                h13.Visibility = Visibility;
                h12.Visibility = Visibility;
                h11.Visibility = Visibility;
                h10.Visibility = Visibility;
                h9.Visibility = Visibility;
                h8.Visibility = Visibility;
                h7.Visibility = Visibility;
                h6.Visibility = Visibility;
                h5.Visibility = Visibility;
                h4.Visibility = Visibility;
                h3.Visibility = Visibility;
                h2.Visibility = Visibility;

                if ((Convert.ToDouble(e.NewValue) > 228)){
                    h2.Visibility = Visibility.Collapsed;
                }
                if ((Convert.ToDouble(e.NewValue) > 235))
                {
                    h3.Visibility = Visibility.Collapsed;
                }
                if ((Convert.ToDouble(e.NewValue) > 239))
                {
                    h4.Visibility = Visibility.Collapsed;
                    h5.Visibility = Visibility.Collapsed;
                }


            }
            if ((Convert.ToDouble(e.NewValue) >246))
            {
                h7.Visibility = Visibility.Collapsed;
                h6.Visibility = Visibility.Collapsed;  
            }

            if ((Convert.ToDouble(e.NewValue) >=246) || (Convert.ToDouble(e.NewValue) == 250))
            {

                h14.Visibility = Visibility.Collapsed;
                h13.Visibility = Visibility.Collapsed;
                h12.Visibility = Visibility.Collapsed;
                h11.Visibility = Visibility.Collapsed;
                h10.Visibility = Visibility.Collapsed;
                h9.Visibility = Visibility.Collapsed;
                h8.Visibility = Visibility.Collapsed;
                h7.Visibility = Visibility.Collapsed;
                h6.Visibility = Visibility.Collapsed;
                h5.Visibility = Visibility.Collapsed;
                h4.Visibility = Visibility.Collapsed;
                h3.Visibility = Visibility.Collapsed;
                h2.Visibility = Visibility.Collapsed;

            }

            if ((Convert.ToDouble(e.NewValue) > 250))
            {
                h1.Y1 = 250;
                h2.Y1 = 250;
                h3.Y1 = 250;
                h4.Y1 = 250;
                h5.Y1 = 250;
                h6.Y1 = 250;
                h7.Y1 = 250;
                h8.Y1 = 250;
                h9.Y1 = 250;
                h10.Y1 = 250;
                h11.Y1 = 250;
                h12.Y1 = 250;
                h13.Y1 = 250;
                h14.Y1 = 250;

                if ((Convert.ToDouble(e.NewValue) != 250) && (Convert.ToDouble(e.NewValue) > 250) && (Convert.ToDouble(e.NewValue) < 401))
                {

                    h14.Y1 = (Convert.ToDouble(e.NewValue));
                    h13.Y1 = (Convert.ToDouble(e.NewValue)) - 1;
                    h12.Y1 = (Convert.ToDouble(e.NewValue)) - 3;
                    h11.Y1 = (Convert.ToDouble(e.NewValue)) - 7;
                    h10.Y1 = (Convert.ToDouble(e.NewValue)) - 11;
                    h9.Y1 = (Convert.ToDouble(e.NewValue)) - 14;
                    h8.Y1 = (Convert.ToDouble(e.NewValue)) - 22;
                    h7.Y1 = (Convert.ToDouble(e.NewValue)) - 31;
                    h6.Y1 = (Convert.ToDouble(e.NewValue)) - 41;
                    h5.Y1 = (Convert.ToDouble(e.NewValue)) - 51;
                    h4.Y1 = (Convert.ToDouble(e.NewValue)) - 68;
                    h3.Y1 = (Convert.ToDouble(e.NewValue)) - 90;
                    h2.Y1 = (Convert.ToDouble(e.NewValue)) - 115;

                    if ((Convert.ToDouble(e.NewValue) <= 385))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 104;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 81;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 60;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) - 39;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) - 27;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                    }
                    if ((Convert.ToDouble(e.NewValue) <= 375))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 98;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 78;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 58;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) - 47;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) - 36;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) - 24;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                    }
                    if ((Convert.ToDouble(e.NewValue) <= 365))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 85;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 67;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 50;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) - 41;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) - 30;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) - 20;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                    }
                    if ((Convert.ToDouble(e.NewValue) <= 352))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 80;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 64;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 48;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) - 38;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) - 28;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) - 16;
                        h9.Y1 = (Convert.ToDouble(e.NewValue)) - 12;
                        h10.Y1 = (Convert.ToDouble(e.NewValue)) - 9;
                        h11.Y1 = (Convert.ToDouble(e.NewValue)) - 5;
                    }

                    if ((Convert.ToDouble(e.NewValue) <= 342))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 72;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 58;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 44;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) - 35;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) - 24;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) - 17;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) - 16;
                        h9.Y1 = (Convert.ToDouble(e.NewValue)) - 9;
                        h10.Y1 = (Convert.ToDouble(e.NewValue)) - 8;
                        h11.Y1 = (Convert.ToDouble(e.NewValue)) - 5;
                    }

                    if ((Convert.ToDouble(e.NewValue) <= 336))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 70;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 55;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 38;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) - 30;
                        h6.Y1 = (Convert.ToDouble(e.NewValue)) - 22;
                        h7.Y1 = (Convert.ToDouble(e.NewValue)) - 14;
                        h8.Y1 = (Convert.ToDouble(e.NewValue)) - 14;
                        h9.Y1 = (Convert.ToDouble(e.NewValue)) - 9;
                        h10.Y1 = (Convert.ToDouble(e.NewValue)) - 6;
                        h11.Y1 = (Convert.ToDouble(e.NewValue)) - 5;
                        if ((Convert.ToDouble(e.NewValue) <= 332))
                        {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) - 64;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) - 50;
                            h7.Y1 = (Convert.ToDouble(e.NewValue)) - 15;
                        }

                    }

                    if ((Convert.ToDouble(e.NewValue) <= 326))
                    {
                        h2.Y1 = (Convert.ToDouble(e.NewValue)) - 60;
                        h3.Y1 = (Convert.ToDouble(e.NewValue)) - 46;
                        h4.Y1 = (Convert.ToDouble(e.NewValue)) - 34;
                        h5.Y1 = (Convert.ToDouble(e.NewValue)) - 28;
                        if ((Convert.ToDouble(e.NewValue) <= 318))
                        {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) - 54;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) - 42;
                            h4.Y1 = (Convert.ToDouble(e.NewValue)) - 31;
                            h5.Y1 = (Convert.ToDouble(e.NewValue)) - 26;
                            h6.Y1 = (Convert.ToDouble(e.NewValue)) - 20;
                            h8.Y1 = (Convert.ToDouble(e.NewValue)) - 12;
                            h11.Y1 = (Convert.ToDouble(e.NewValue)) - 4;
                        }
                        if ((Convert.ToDouble(e.NewValue) <= 311))
                        {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) - 48;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) - 38;
                            h4.Y1 = (Convert.ToDouble(e.NewValue)) - 30;
                            h5.Y1 = (Convert.ToDouble(e.NewValue)) - 23;
                            h6.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                            h8.Y1 = (Convert.ToDouble(e.NewValue)) - 12;
                            h11.Y1 = (Convert.ToDouble(e.NewValue)) - 4;
                        }
                        if ((Convert.ToDouble(e.NewValue) <= 304))
                        {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) - 43;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) - 32;
                            h4.Y1 = (Convert.ToDouble(e.NewValue)) - 26;
                            h5.Y1 = (Convert.ToDouble(e.NewValue)) - 21;
                            h6.Y1 = (Convert.ToDouble(e.NewValue)) - 15;
                            h7.Y1 = (Convert.ToDouble(e.NewValue)) - 12;
                            h8.Y1 = (Convert.ToDouble(e.NewValue)) - 10;
                            h9.Y1 = (Convert.ToDouble(e.NewValue)) - 8;
                            h10.Y1 = (Convert.ToDouble(e.NewValue)) - 5;
                            h11.Y1 = (Convert.ToDouble(e.NewValue)) - 3;
                        }
                        if ((Convert.ToDouble(e.NewValue) <= 297))
                        {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) - 35;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) - 28;
                            h4.Y1 = (Convert.ToDouble(e.NewValue)) - 22;
                            h5.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                            if ((Convert.ToDouble(e.NewValue) <= 290))
                            {
                                h2.Y1 = (Convert.ToDouble(e.NewValue)) - 31;
                                h3.Y1 = (Convert.ToDouble(e.NewValue)) - 24;
                                h4.Y1 = (Convert.ToDouble(e.NewValue)) - 17;
                                h5.Y1 = (Convert.ToDouble(e.NewValue)) - 16;
                                h6.Y1 = (Convert.ToDouble(e.NewValue)) - 12;
                                h7.Y1 = (Convert.ToDouble(e.NewValue)) - 9;
                                h8.Y1 = (Convert.ToDouble(e.NewValue)) - 8;
                                h9.Y1 = (Convert.ToDouble(e.NewValue)) - 6;
                            }

                        }
                        if ((Convert.ToDouble(e.NewValue) <= 285))
                        {
                            h2.Y1 = (Convert.ToDouble(e.NewValue)) - 28;
                            h3.Y1 = (Convert.ToDouble(e.NewValue)) - 20;
                            h4.Y1 = (Convert.ToDouble(e.NewValue)) - 15;
                            h5.Y1 = (Convert.ToDouble(e.NewValue)) - 13;
                            h6.Y1 = (Convert.ToDouble(e.NewValue)) - 10;
                            h7.Y1 = (Convert.ToDouble(e.NewValue)) - 7;
                            h8.Y1 = (Convert.ToDouble(e.NewValue)) - 6;
                            h9.Y1 = (Convert.ToDouble(e.NewValue)) - 4;
                            if ((Convert.ToDouble(e.NewValue) <= 280))
                            {
                                h2.Y1 = (Convert.ToDouble(e.NewValue)) - 25;
                            }
                            if ((Convert.ToDouble(e.NewValue) <= 272))
                            {
                                h2.Y1 = (Convert.ToDouble(e.NewValue)) - 18;
                                h3.Y1 = (Convert.ToDouble(e.NewValue)) - 13;
                                h4.Y1 = (Convert.ToDouble(e.NewValue)) - 11;
                                h5.Y1 = (Convert.ToDouble(e.NewValue)) - 10;
                                h6.Y1 = (Convert.ToDouble(e.NewValue)) - 7;
                                h7.Y1 = (Convert.ToDouble(e.NewValue)) - 4;
                                h8.Y1 = (Convert.ToDouble(e.NewValue)) - 3;
                                h9.Y1 = (Convert.ToDouble(e.NewValue)) - 2;
                                h10.Y1 = (Convert.ToDouble(e.NewValue)) - 3;
                                h11.Y1 = (Convert.ToDouble(e.NewValue)) - 1;
                            }
                            if ((Convert.ToDouble(e.NewValue) <= 266))
                            {
                                h2.Y1 = (Convert.ToDouble(e.NewValue)) - 14;
                                h3.Y1 = (Convert.ToDouble(e.NewValue)) - 10;
                                h4.Y1 = (Convert.ToDouble(e.NewValue)) - 9;
                                h5.Y1 = (Convert.ToDouble(e.NewValue)) - 4;
                                h6.Y1 = (Convert.ToDouble(e.NewValue)) - 4;
                            }

                        }



                    }

                    h14.Visibility = Visibility;
                    h13.Visibility = Visibility;
                    h12.Visibility = Visibility;
                    h11.Visibility = Visibility;
                    h10.Visibility = Visibility;
                    h9.Visibility = Visibility;
                    h8.Visibility = Visibility;
                    h7.Visibility = Visibility;
                    h6.Visibility = Visibility;
                    h5.Visibility = Visibility;
                    h4.Visibility = Visibility;
                    h3.Visibility = Visibility;
                    h2.Visibility = Visibility;

                    if ((Convert.ToDouble(e.NewValue) <= 261))
                    {
                        h2.Visibility = Visibility.Collapsed;
                    }
                    if ((Convert.ToDouble(e.NewValue) <= 256))
                    {
                        h3.Visibility = Visibility.Collapsed;
                        h4.Visibility = Visibility.Collapsed;
                    }

                }
            }

        }

        private void MySlider2_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            //double val = Path2.ActualHeight;
            //Messagebox.Text = " " + val;
            Curve3.StartPoint = new Point(300, 1 * (Convert.ToDouble(e.NewValue)));
            //MyCurve3.Point1 = new Point(350, 1 * ((Convert.ToDouble(e.NewValue)) + 10));

            MyCurve2.Point3 = new Point(300, 1 * (Convert.ToDouble(e.NewValue)));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve2.Point2 = new Point(225, (1 * (Convert.ToDouble(e.NewValue))) - 10);      
                MyCurve3.Point1 = new Point(350, 1 * ((Convert.ToDouble(e.NewValue)) + 10));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250) {
                MyCurve2.Point2 = new Point(225, 250);
                MyCurve2.Point1 = new Point(240, 250);
            }   
        }

        private void MySlider3_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            MyCurve3.Point3 = new Point(450, 1 * (Convert.ToDouble(e.NewValue)));
            Curve4.StartPoint = new Point(450, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve4.Point1= new Point(500, 1 * ((Convert.ToDouble(e.NewValue))));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve3.Point2 = new Point(400, 1 * (Convert.ToDouble(e.NewValue)));
            
            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve3.Point2 = new Point(400, 250);
                MyCurve3.Point1 = new Point(350, 250);
            }

        }

        private void MySlider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            //MyCurve4.Point3 = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
            //MyCurve4.Point2 = new Point(500, 1 * ((Convert.ToDouble(e.NewValue))-10));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve4.Point3 = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
                MyCurve4.Point2 = new Point(500, 1 * ((Convert.ToDouble(e.NewValue)) - 10));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve4.Point3 = new Point(600, 250);
                MyCurve4.Point2 = new Point(500,250);
            }

            Curve5.StartPoint = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve5.Point1 = new Point(660, 1 * (Convert.ToDouble(e.NewValue)));


        }

        private void MySlider5_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            double val = (Convert.ToDouble(e.NewValue));
            if (val % 10 != 0) {

                int rem = (int)val % 10;
                if (rem < 5)
                {
                    val = val - rem;
                }
                else {
                    val = val +(10 - rem);
                }
            }

            MySlider5.Value = val;
            if (val != 250)
            {
                MyCurve5.Point2 = new Point(700, 1 * (val + 10));
                MyCurve5.Point3 = new Point(750, 1 * (val));

            }
            else if (val == 250)
            {
                MyCurve5.Point2 = new Point(700, 250);
                MyCurve5.Point3 = new Point(750, 250);
            }
            //MyCurve5.Point2 = new Point(700, 1 * ((Convert.ToDouble(e.NewValue))+10));
            //MyCurve5.Point3 = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve6.Point1 = new Point(810, 1 * (val));
            Curve6.StartPoint = new Point(750, 1 * val);

            h37.Y2 = 250;
            h38.Y2 = 250;
            h39.Y2 = 250;
            h40.Y2 = 250;
            h41.Y2 = 250;
            h42.Y2 = 250;
            h43.Y2 = 250;
            h44.Y2 = 250;
            h45.Y2 = 250;
            h46.Y2 = 250;
            h47.Y2 = 250;
            h48.Y2 = 250;
            h49.Y2 = 250;

            if (val >= 30 && val != 250)
            {

                h37.Y1 = val;
                h38.Y1 = val + 5;
                h39.Y1 = val + 12;
                h40.Y1 = val + 22;
                h41.Y1 = val + 33;
                h42.Y1 = val + 47;
                h43.Y1 = val + 63;
                h44.Y1 = val + 79;
                h45.Y1 = val + 99;
                h46.Y1 = val + 121;
                h47.Y1 = val + 149;
                h48.Y1 = val + 170;
                h49.Y1 = val + 198;
                if (val >= 50)
                {
                    h42.Y1 = val + 45;
                    h43.Y1 = val + 60;
                    h44.Y1 = val + 75;
                    h45.Y1 = val + 95;
                    h46.Y1 = val + 113;
                    h47.Y1 = val + 138;
                    h48.Y1 = val + 158;
                    h49.Y1 = val + 180;
                }
                if (val >= 70)
                {
                    h40.Y1 = val + 20;
                    h41.Y1 = val + 30;
                    h42.Y1 = val + 40;
                    h43.Y1 = val + 56;
                    h44.Y1 = val + 70;
                    h45.Y1 = val + 85;
                    h46.Y1 = val + 100;
                    h47.Y1 = val + 120;
                    h48.Y1 = val + 140;
                    h49.Y1 = val + 160;
                }

                if (val >= 90)
                {
                    h40.Y1 = val + 16;
                    h41.Y1 = val + 26;
                    h42.Y1 = val + 36;
                    h43.Y1 = val + 50;
                    h44.Y1 = val + 61;
                    h45.Y1 = val + 78;
                    h46.Y1 = val + 95;
                    h47.Y1 = val + 108;
                    h48.Y1 = val + 124;
                    h49.Y1 = val + 144;
                    if (val >= 100)
                    {
                        h39.Y1 = val + 9;
                        h40.Y1 = val + 14;
                        h41.Y1 = val + 24;
                        h42.Y1 = val + 34;
                        h43.Y1 = val + 46;
                        h44.Y1 = val + 58;
                        h45.Y1 = val + 71;
                        h46.Y1 = val + 86;
                        h47.Y1 = val + 98;
                        h48.Y1 = val + 116;
                        h49.Y1 = val + 132;

                    }

                }

                if (val >= 120)
                {

                    h39.Y1 = val + 7;
                    h40.Y1 = val + 12;
                    h41.Y1 = val + 21;
                    h42.Y1 = val + 31;
                    h43.Y1 = val + 41;
                    h44.Y1 = val + 50;
                    h45.Y1 = val + 63;
                    h46.Y1 = val + 74;
                    h47.Y1 = val + 85;
                    h48.Y1 = val + 98;
                    h49.Y1 = val + 116;
                    if (val >= 130)
                    {
                        h42.Y1 = val + 29;
                        h43.Y1 = val + 39;
                        h44.Y1 = val + 48;
                        h45.Y1 = val + 58;
                        h46.Y1 = val + 70;
                        h47.Y1 = val + 81;
                        h48.Y1 = val + 91;
                        h49.Y1 = val + 108;
                    }

                    if (val >= 140)
                    {
                        h41.Y1 = val + 18;
                        h42.Y1 = val + 25;
                        h43.Y1 = val + 35;
                        h44.Y1 = val + 43;
                        h45.Y1 = val + 53;
                        h46.Y1 = val + 63;
                        h47.Y1 = val + 74;
                        h48.Y1 = val + 86;
                        h49.Y1 = val + 98;
                    }
                }
                if (val >= 150)
                {
                    h39.Y1 = val + 6;
                    h40.Y1 = val + 10;
                    h41.Y1 = val + 18;
                    h42.Y1 = val + 20;
                    h43.Y1 = val + 29;
                    h44.Y1 = val + 39;
                    h45.Y1 = val + 45;
                    h46.Y1 = val + 54;
                    h47.Y1 = val + 66;
                    h48.Y1 = val + 76;
                    h49.Y1 = val + 86;
                }

                if (val >= 170)
                {
                    h38.Y1 = val + 3;
                    h39.Y1 = val + 4;
                    h40.Y1 = val + 8;
                    h41.Y1 = val + 15;
                    h42.Y1 = val + 16;
                    h43.Y1 = val + 22;
                    h44.Y1 = val + 31;
                    h45.Y1 = val + 38;
                    h46.Y1 = val + 42;
                    h47.Y1 = val + 51;
                    h48.Y1 = val + 62;
                    h49.Y1 = val + 70;
                    if (val >= 180)
                    {
                        h41.Y1 = val + 11;
                        h42.Y1 = val + 13;
                        h43.Y1 = val + 19;
                        h44.Y1 = val + 26;
                        h45.Y1 = val + 32;
                        h46.Y1 = val + 37;
                        h47.Y1 = val + 45;
                        h48.Y1 = val + 52;
                        h49.Y1 = val + 63;
                    }

                }

                if (val >= 200)
                {
                    //h49.Visibility = Visibility.Collapsed;
                    h41.Y1 = val + 8;
                    h42.Y1 = val + 9;
                    h43.Y1 = val + 11;
                    h44.Y1 = val + 18;
                    h45.Y1 = val + 26;
                    h46.Y1 = val + 30;
                    h47.Y1 = val + 35;
                    h48.Y1 = val + 42;

                    if (val >= 210)
                    {
                        h40.Y1 = val + 6;
                        h43.Y1 = val + 9;
                        h44.Y1 = val + 14;
                        h45.Y1 = val + 20;
                        h46.Y1 = val + 21;
                        h47.Y1 = val + 28;
                        h48.Y1 = val + 32;
                    }
                }

                if (val >= 230)
                {

                    //h48.Visibility = Visibility.Collapsed;
                    //h47.Visibility = Visibility.Collapsed;
                    //h46.Visibility = Visibility.Collapsed;
                    h40.Y1 = val + 4;
                    h43.Y1 = val + 7;
                    h44.Y1 = val + 11;
                    h45.Y1 = val + 16;
                }
                //if (val >= 200)
                //{
                //    //h49.Visibility = Visibility.Collapsed;

                //}
                h37.Visibility = Visibility;
                h38.Visibility = Visibility;
                h39.Visibility = Visibility;
                h40.Visibility = Visibility;
                h41.Visibility = Visibility;
                h42.Visibility = Visibility;
                h43.Visibility = Visibility;
                h44.Visibility = Visibility;
                h45.Visibility = Visibility;
                h46.Visibility = Visibility;
                h47.Visibility = Visibility;
                h48.Visibility = Visibility;
                h49.Visibility = Visibility;



            }

            }

        //private void Slider5_Pressed(object sender, PointerEventHandler e) {
        //    h36.Visibility = Visibility.Collapsed;
        //    h37.Visibility = Visibility.Collapsed;
        //    h38.Visibility = Visibility.Collapsed;
        //    h39.Visibility = Visibility.Collapsed;
        //    h40.Visibility = Visibility.Collapsed;
        //    h41.Visibility = Visibility.Collapsed;
        //    h42.Visibility = Visibility.Collapsed;
        //    h43.Visibility = Visibility.Collapsed;


        //}


        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            MyCurve1.Point1 = new Point(50, 250);
            MyCurve1.Point2 = new Point(150, 250);
            Curve2.StartPoint = new Point(150, 250);
            MyCurve2.Point1 = new Point(240, 250);
            MyCurve2.Point2 = new Point(250, 250);
            MyCurve2.Point3 = new Point(300, 250);
            Curve3.StartPoint = new Point(300,250);
            MyCurve3.Point1 = new Point(350, 250);
            MyCurve3.Point2 = new Point(400, 250);
            MyCurve3.Point3 = new Point(450, 250);
            Curve4.StartPoint = new Point(450, 250);
            MyCurve4.Point1 = new Point(500, 250);
            MyCurve4.Point2 = new Point(500, 250);
            MyCurve4.Point3 = new Point(600, 250);
            Curve5.StartPoint = new Point(600,250);
            MyCurve5.Point1 = new Point(660,250);
            MyCurve5.Point2 = new Point(700, 250);
            MyCurve5.Point3 = new Point(750, 250);
            Curve6.StartPoint = new Point(750, 250);
            MyCurve6.Point1 = new Point(810, 250);
            MySlider1.Value = 250;
            MySlider2.Value = 250;
            MySlider3.Value = 250;
            MySlider4.Value = 250;
            MySlider5.Value = 250;

        }

        private void MouseValues(object sender, PointerRoutedEventArgs e)
        {
            PointerPoint point = e.GetCurrentPoint(Path5);

            var x = (Int16)point.Position.X;
            var y = (Int16)point.Position.Y;
            Messagebox.Text = " " + x + "," + y;

        }
    }
}
