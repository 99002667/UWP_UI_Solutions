﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace RelativeLayout
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Grid_View : Page
    {
        public ObservableCollection<Book> booklist;
        public Grid_View()
        {
            this.InitializeComponent();
            booklist = Book.GetBooks();
            this.DataContext = booklist;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string ID_ = Id.Text;
            string Title_ = Title.Text;
            string Author_ = Author.Text;
            string Image_ = Image.Text;
            booklist.Add(new Book() { Id = "ID: " + ID_, Title = "Title: " + Title.Text, Author = Author_, Image = Image_ });
            this.DataContext = booklist;
        }

        private void MainPage_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }
    }
  }

