﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RelativeLayout
{
    public class Book
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Image { get; set; }


        public static ObservableCollection<Book> GetBooks()
        {
            ObservableCollection<Book> books = new ObservableCollection<Book>();

            books.Add(new Book { Id = "ID = 1", Title = "Title: The Hyprocatic World", Author = "Author1", Image = "Assets/Images/b1.jpg" });
            books.Add(new Book { Id = "ID = 2", Title = "Title: The Journey to the stars", Author = "Matt Zhang", Image = "Assets/Images/b2.jpg" });
            books.Add(new Book { Id = "ID = 3", Title = "Title: The King of Drugs", Author = "Nora Barrett", Image = "Assets/Images/b3.jpg" });
            books.Add(new Book { Id = "ID = 4", Title = "Title: Silence", Author = "Author4", Image = "Assets/Images/b4.jpg" });
            books.Add(new Book { Id = "ID = 5", Title = "Title: Cindrella", Author = "Author5", Image = "Assets/Images/b5.jpg" });
            books.Add(new Book { Id = "ID = 6", Title = "Title: The Hyprocatic World", Author = "Author1", Image = "Assets/Images/b1.jpg" });
            books.Add(new Book { Id = "ID = 7", Title = "Title: The Journey to the stars", Author = "Matt Zhang", Image = "Assets/Images/b2.jpg" });
            books.Add(new Book { Id = "ID = 8", Title = "Title: The King of Drugs", Author = "Nora Barrett", Image = "Assets/Images/b3.jpg" });
            books.Add(new Book { Id = "ID = 9", Title = "Title: Silence", Author = "Author4", Image = "Assets/Images/b4.jpg" });
            books.Add(new Book { Id = "ID = 10", Title = "Title: Cindrella", Author = "Author5", Image = "Assets/Images/b5.jpg" });

            return books;
        }
    }
}
