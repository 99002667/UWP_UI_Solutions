﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace RelativeLayout
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BlankPage1 : Page
    {
     
        public ObservableCollection<SampleItem> flipViewData { get; set; }

        public BlankPage1()
        {
            this.InitializeComponent();
          
            flipViewData = new ObservableCollection<SampleItem>();
            flipViewData.Add(new SampleItem() { Name = "Great Wall of China", Image = "/Assets/Images/GreatWallofChina.jpeg" });
            flipViewData.Add(new SampleItem() { Name = "Machu Pichu", Image = "/Assets/Images/MachuPichu.jpeg" });
            flipViewData.Add(new SampleItem() { Name = "Taj Mahal", Image = "/Assets/Images/TajMahal.jpeg" });
            flipViewData.Add(new SampleItem() { Name = "Picture using URL", Image = "https://images.pexels.com/photos/2325446/pexels-photo-2325446.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" });
            flipViewData.Add(new SampleItem() { Name = "petra", Image = "/Assets/Images/petra.jpeg" });
            flipViewData.Add(new SampleItem() { Name = "Great Wall of China", Image = "/Assets/Images/GreatWallofChina.jpeg" });
            flipView1.ItemsSource = flipViewData;
        }

    
       
        private void add_Clicked(object sender, RoutedEventArgs e)
        {
            string New_Name = name.Text;
            string New_Source = source.Text;
            flipViewData.Add(new SampleItem() { Name = New_Name, Image = New_Source });
            flipView1.ItemsSource = flipViewData;
           
        }

        private void Mainpage_Clicked(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
          // int Index = int.Parse(Remove_text.Text);
           // string New_Name = name.Text;
          //  flipViewData.Insert(Index, new SampleItem() { Name = New_Name });

        }

        private void Remove_Clicked(object sender, RoutedEventArgs e)
        {
           
            int Index = int.Parse(Remove_text.Text);
            flipViewData.RemoveAt(Index-1);
        }

        
    }

    public class SampleItem
    {
        public string Name { get; set; }
        public string Image { get; set; }
    }
}
