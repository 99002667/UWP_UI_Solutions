﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Relative__Layout
{
    public sealed partial class Calculator : UserControl
    {
        public Calculator()
        {
            this.InitializeComponent();
        }

        private void ADD_Click(object sender, RoutedEventArgs e)
        {
            int op1 = int.Parse(FirstOperand.Text);
            int op2 = int.Parse(SecondOperand.Text);
            int res = op1 + op2;
            Result.Text = res + "";
        }

        private void SUB_Click(object sender, RoutedEventArgs e)
        {
            int op1 = int.Parse(FirstOperand.Text);
            int op2 = int.Parse(SecondOperand.Text);
            int res = op1 - op2;
            Result.Text = res + "";
        }

        private void MUL_Click(object sender, RoutedEventArgs e)
        {
            int op1 = int.Parse(FirstOperand.Text);
            int op2 = int.Parse(SecondOperand.Text);
            int res = op1 * op2;
            Result.Text = res + "";
        }

        private void DIV_Click(object sender, RoutedEventArgs e)
        {
            int op1 = int.Parse(FirstOperand.Text);
            int op2 = int.Parse(SecondOperand.Text);
            int res = op1 / op2;
            Result.Text = res + "";
        }

        private void MOD_Click(object sender, RoutedEventArgs e)
        {
            int op1 = int.Parse(FirstOperand.Text);
            int op2 = int.Parse(SecondOperand.Text);
            int res = op1 % op2;
            Result.Text = res + "";
        }
    }
}
