﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyncfusionUWP_Curve_Creation
{
    class ViewModel
    {
        public List<Info> Data { get; set; }

        public ViewModel()
        {
            Data = new List<Info>()
            {
                new Info { x_Axis= "0", Y_Axis = 0, Y1 = 0 },
                new Info{ x_Axis= "10", Y_Axis = 10, Y1 = 10},
                new Info {x_Axis= "20", Y_Axis = 20, Y1 = 20 },
                new Info {x_Axis= "30", Y_Axis = 30,Y1 = 30 },
                new Info {x_Axis= "40", Y_Axis = 20, Y1 = 20},
                new Info {x_Axis= "50", Y_Axis = 10, Y1 = 10},
                new Info {x_Axis= "60", Y_Axis = 0, Y1 = 0 }

            };
        }
    }
}
