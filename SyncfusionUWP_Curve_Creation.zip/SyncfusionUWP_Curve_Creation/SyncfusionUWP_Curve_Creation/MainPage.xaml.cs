﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Syncfusion.UI.Xaml.Charts;
using Syncfusion.Drawing;
using Windows.UI;
// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace SyncfusionUWP_Curve_Creation
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            SfChart chart = new SfChart();
            SfChart chart1 = new SfChart();

            chart1.Legend = new ChartLegend();
            CategoryAxis primaryAxis = new CategoryAxis();

            chart.PrimaryAxis = primaryAxis;

            NumericalAxis secondaryAxis = new NumericalAxis();

            chart.SecondaryAxis = secondaryAxis;
            this.DataContext = new ViewModel();


            SplineAreaSeries series = new SplineAreaSeries()
            {

                ItemsSource = new ViewModel().Data,

                XBindingPath = "x_Axis",

                YBindingPath = "Y_Axis",


            };


            BubbleSeries series1 = new BubbleSeries()
            {

                ItemsSource = new ViewModel().Data,

                XBindingPath = "x_Axis",

                YBindingPath = "Y1",

                Size = "Size",

                MinimumRadius = 5,

                Interior = new SolidColorBrush(Colors.Green)

            };
            chart.Series.Add(series);
            chart1.Series.Add(series1);

        }

    }
    public class Info
    {
        public string x_Axis { get; set; }

        public double Y_Axis { get; set; }

        public double Y1 { get; set; }

    }
}
