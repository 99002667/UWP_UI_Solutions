﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Pivot_Ex.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Pivot_Ex
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        EqualizerGraph graph1 = new EqualizerGraph();
        EqualizerGraph graph2 = new EqualizerGraph();
        EqualizerGraph graph3 = new EqualizerGraph();
        EqualizerGraph Custome_graph4 = new EqualizerGraph();

        public MainPage()
        {
            this.InitializeComponent();
            Application.Current.Resources["ToggleSwitchFillOn"] = new SolidColorBrush(Windows.UI.Colors.Black);
            Application.Current.Resources["ToggleSwitchKnobFillOff"] = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            Application.Current.Resources["ToggleSwitchFillOff"] = new SolidColorBrush(Windows.UI.Colors.Black);
            Application.Current.Resources["ToggleSwitchKnobFillOn"] = new SolidColorBrush(Windows.UI.Colors.Gray);
            Application.Current.Resources["ToggleSwitchStrokeOff"] = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            Application.Current.Resources["ToggleSwitchStrokeOn"] = new SolidColorBrush(Windows.UI.Colors.Gray);
           

        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Xbox));
        }

        private void MySwitch_Toggled(object sender, RoutedEventArgs e)
        {




            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {

                    MyText.Text = "Inactive";
                    MyText.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    MyText.Visibility = Visibility.Visible;
                }
                else
                {
                    MyText.Text = "Active";
                    MyText.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    MyText.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch2_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text2.Text = "Inactive";
                    Text2.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text2.Visibility = Visibility.Visible;
                }
                else
                {
                    Text2.Text = "Active";
                    Text2.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text2.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch3_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text3.Text = "Inactive";
                    Text3.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text3.Visibility = Visibility.Visible;
                }
                else
                {
                    Text3.Text = "Active";
                    Text3.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text3.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch4_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text4.Text = "Inactive";
                    Text4.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text4.Visibility = Visibility.Visible;
                }
                else
                {
                    Text4.Text = "Active";
                    Text4.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text4.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch5_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text5.Text = "Inactive";
                    Text5.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text5.Visibility = Visibility.Visible;
                }
                else
                {
                    Text5.Text = "Active";
                    Text5.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text5.Visibility = Visibility.Visible;
                }
            }
        }


        private void MyText_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (TextBox.Text == "Inactive Profile")
            {
                TextBox.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if ((string)e.Parameter == "Active Profile" || (string)e.Parameter == "Inactive Profile")
            {
                TextBox.Text = $"{e.Parameter.ToString()}";
                if ((string)e.Parameter == "Inactive Profile")
                {
                    TextBox.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                }
            }
            else
            {
                TextBox.Text = "Active Profile";
            }
            base.OnNavigatedTo(e);
        }

         private void Graph1_Clicked(object sender, RoutedEventArgs e)
        {
            
            Grid1.Children.Clear();
            var Slider1 = graph1.FindName("MySlider") as Slider;
            Slider1.Value = 36;
            Slider1.IsHitTestVisible = false;
            var Slider2 = graph1.FindName("MySlider2") as Slider;
            Slider2.Value = 95;
            Slider2.IsHitTestVisible = false;
            var Slider3 = graph1.FindName("MySlider3") as Slider;
            Slider3.Value = 30;
            Slider3.IsHitTestVisible = false;
            var Slider4 = graph1.FindName("MySlider4") as Slider;
            Slider4.Value = -68;
            Slider4.IsHitTestVisible = false;
            var Slider5 = graph1.FindName("MySlider5") as Slider;
            Slider5.Value = 62;
            Slider5.IsHitTestVisible = false;

            graph1.HorizontalAlignment = HorizontalAlignment.Center;
            graph1.VerticalAlignment = VerticalAlignment.Center;
            Grid1.Children.Add(graph1);
           

        }

        private void Graph2_Clicked(object sender, RoutedEventArgs e)
        {
            Grid1.Children.Clear();
            var Slider1 = graph2.FindName("MySlider") as Slider;
            Slider1.Value = 36;
            Slider1.IsHitTestVisible = false;
            var Slider2 = graph2.FindName("MySlider2") as Slider;
            Slider2.Value = 95;
            Slider2.IsHitTestVisible = false;
            var Slider3 = graph2.FindName("MySlider3") as Slider;
            Slider3.Value = -86;
            Slider3.IsHitTestVisible = false;
            var Slider4 = graph2.FindName("MySlider4") as Slider;
            Slider4.Value = 45;
            Slider4.IsHitTestVisible = false;
            var Slider5 = graph2.FindName("MySlider5") as Slider;
            Slider5.Value = -31;
            Slider5.IsHitTestVisible = false;

            graph2.HorizontalAlignment = HorizontalAlignment.Center;
            graph2.VerticalAlignment = VerticalAlignment.Center;
          
            Grid1.Children.Add(graph2);
           
        }

        private void Graph3_Clicked(object sender, RoutedEventArgs e)
        {
            Grid1.Children.Clear();
            var Slider1 = graph3.FindName("MySlider") as Slider;
            Slider1.Value = -15;
            Slider1.IsHitTestVisible = false;
            var Slider2 = graph3.FindName("MySlider2") as Slider;
            Slider2.Value = -75;
            Slider2.IsHitTestVisible = false;
            var Slider3 = graph3.FindName("MySlider3") as Slider;
            Slider3.Value = 68;
            Slider3.IsHitTestVisible = false;
            var Slider4 = graph3.FindName("MySlider4") as Slider;
            Slider4.Value = -42;
            Slider4.IsHitTestVisible = false;
            var Slider5 = graph3.FindName("MySlider5") as Slider;
            Slider5.Value = 30;
            Slider5.IsHitTestVisible = false;
            graph3.HorizontalAlignment = HorizontalAlignment.Center;
            graph3.VerticalAlignment = VerticalAlignment.Center;          
            Grid1.Children.Add(graph3);
           ;

        }

        private void customGraph_Clicked(object sender, RoutedEventArgs e)
        {
            Grid1.Children.Clear();
            Custome_graph4.HorizontalAlignment = HorizontalAlignment.Center;
            Custome_graph4.VerticalAlignment = VerticalAlignment.Center;     
            Grid1.Children.Add(Custome_graph4);
            

        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {


            var Slider1 = Custome_graph4.FindName("MySlider") as Slider;
            Slider1.Value = 0;
            
            var Slider2 = Custome_graph4.FindName("MySlider2") as Slider;
            Slider2.Value = 0;
          
            var Slider3 = Custome_graph4.FindName("MySlider3") as Slider;
            Slider3.Value = 0;
           
            var Slider4 = Custome_graph4.FindName("MySlider4") as Slider;
            Slider4.Value = 0;
            
            var Slider5 = Custome_graph4.FindName("MySlider5") as Slider;
            Slider5.Value = 0;
            
           
          


        }
    }
}
