﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409


namespace UI_Design
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            Application.Current.Resources["ToggleSwitchFillOn"] = new SolidColorBrush(Windows.UI.Colors.Black);
            Application.Current.Resources["ToggleSwitchKnobFillOff"] = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            Application.Current.Resources["ToggleSwitchFillOff"] = new SolidColorBrush(Windows.UI.Colors.Black);
            Application.Current.Resources["ToggleSwitchKnobFillOn"] = new SolidColorBrush(Windows.UI.Colors.Gray);
            Application.Current.Resources["ToggleSwitchStrokeOff"] = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
            Application.Current.Resources["ToggleSwitchStrokeOn"] = new SolidColorBrush(Windows.UI.Colors.Gray);


        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Xbox));
        }
        
        private void MySwitch_Toggled(object sender, RoutedEventArgs e)
        {
            
            
            
            
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
  
                    MyText.Text = "Inactive";
                    MyText.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    MyText.Visibility = Visibility.Visible;
                }
                else
                {
                    MyText.Text = "Active";
                    MyText.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    MyText.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch2_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text2.Text = "Inactive";
                    Text2.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text2.Visibility = Visibility.Visible;
                }
                else
                {
                    Text2.Text = "Active";
                    Text2.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text2.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch3_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text3.Text = "Inactive";
                    Text3.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text3.Visibility = Visibility.Visible;
                }
                else
                {
                    Text3.Text = "Active";
                    Text3.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text3.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch4_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text4.Text = "Inactive";
                    Text4.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text4.Visibility = Visibility.Visible;
                }
                else
                {
                    Text4.Text = "Active";
                    Text4.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text4.Visibility = Visibility.Visible;
                }
            }
        }

        private void Switch5_Toggled(object sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch)
            {
                var toggle = (ToggleSwitch)sender;
                if (toggle.IsOn)
                {
                    Text5.Text = "Inactive";
                    Text5.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                    Text5.Visibility = Visibility.Visible;
                }
                else
                {
                    Text5.Text = "Active";
                    Text5.Foreground = new SolidColorBrush(Windows.UI.Colors.OrangeRed);
                    Text5.Visibility = Visibility.Visible;
                }
            }
        }


        private void MyText_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (TextBox.Text == "Inactive Profile") {
                TextBox.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if ((string)e.Parameter == "Active Profile" || (string)e.Parameter == "Inactive Profile")
            {
                TextBox.Text = $"{e.Parameter.ToString()}";
                if ((string)e.Parameter == "Inactive Profile")
                {
                    TextBox.Foreground = new SolidColorBrush(Windows.UI.Colors.Gray);
                }
            }
            else
            {
                TextBox.Text = "Active Profile";
            }
            base.OnNavigatedTo(e);
        }

        private void TextBlock_SelectionChanged_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
