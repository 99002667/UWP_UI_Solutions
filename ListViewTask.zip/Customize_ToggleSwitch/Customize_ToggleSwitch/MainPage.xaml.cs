﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Customize_ToggleSwitch
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        ObservableCollection<Listview2details> _reference;
        ObservableCollection<Listview2details> _selection;
        private ListView dragListView;
        private ObservableCollection<Listview2details> dragCollection;
        private ObservableCollection<Listview2details> dropCollection;
       
        private ListView dropListView;
        private object dragedItem;

        public MainPage()
        {
            this.InitializeComponent();     
            _reference = GetData_list();
            _selection = new ObservableCollection<Listview2details>();
            //_selection = GetData2_list();
            Source.ItemsSource = _reference;
            Target.ItemsSource = _selection;
        }

        private ObservableCollection<Listview2details> GetData_list()
        {
            return new ObservableCollection<Listview2details>
            {
               new Listview2details() { Title = "Item1" },
               new Listview2details() { Title = "Item2" },
               new Listview2details() { Title = "Item3" },
               new Listview2details() { Title = "Item4" },
               new Listview2details() { Title = "Item5" },
               new Listview2details() { Title = "Item6" }

        };

        }
        //private ObservableCollection<Listview2details> GetData2_list()
        //{
        //    return new ObservableCollection<Listview2details>
        //    {
        //       new Listview2details() { Title = "Target_Item1" },
        //       new Listview2details() { Title = "Target_Item2" },          
        //};

        //}



        private void SourceList_DragItemsStarting(object sender, DragItemsStartingEventArgs e)
        {
            var listView = sender as ListView;
            if (listView != null)
            {
                dragListView = listView;
                dragCollection = listView.ItemsSource as ObservableCollection<Listview2details>;


                if (e.Items.Count == 1)
                {
                    dragedItem = e.Items[0];
                    e.Data.RequestedOperation = Windows.ApplicationModel.DataTransfer.DataPackageOperation.Copy;
                }
            }
        }



        private void TargetList_DragOver(object sender, DragEventArgs e)
        {
           
            e.AcceptedOperation = DataPackageOperation.Copy;
        }





        //in/*t count = 0;*/

        private void TargetList_Drop(object sender, DragEventArgs e)
        {
            var scrollViewer = VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(Target, 0), 0) as ScrollViewer;
            var position = e.GetPosition((ListView)sender);
            var positionY = scrollViewer.VerticalOffset + position.Y;
            var index = GetItemIndex(positionY, Target);

            dropListView = sender as ListView;

            if (dropListView != null)
            {
                dropCollection = dropListView.ItemsSource as ObservableCollection<Listview2details>;

                if (dragedItem != null)
                {
                    //count += 1;
                    if (_selection.Count>= 2) {
                        _selection.RemoveAt(index);
                    }

                    dropCollection.Insert(index, dragedItem as Listview2details);
                        dragedItem = null;
                   
                }
            }

        }

        private void Source_Drop(object sender, DragEventArgs e)
        {
            var scrollViewer = VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(Source, 0), 0) as ScrollViewer;
            var position = e.GetPosition((ListView)sender);
            var positionY = scrollViewer.VerticalOffset + position.Y;
            var index = GetItemIndex(positionY, Source);

            dropListView = sender as ListView;

            if (dropListView != null)
            {
                dropCollection = dropListView.ItemsSource as ObservableCollection<Listview2details>;

                if (dragedItem != null)
                {
                    _reference.Remove(dragedItem as Listview2details);
                    dropCollection.Insert(index, dragedItem as Listview2details);
                }
            }

        }

        int GetItemIndex(double positionY, ListView targetListView)
        {
            var index = 0;
            double height = 0;

            foreach (var item in targetListView.Items)
            {
                height += GetRowHeight(item, targetListView);
                if (height > positionY) return index;
                index++;
            }
            return index;
        }


        double GetRowHeight(object listItem, ListView targetListView)
        {
            var listItemContainer = targetListView.ContainerFromItem(listItem) as ListViewItem;
            var height = listItemContainer.ActualHeight;
            var marginTop = listItemContainer.Margin.Top;
            return marginTop + height;
        }

        private void Source_DragEnter(object sender, DragEventArgs e)
        {
            e.AcceptedOperation = (e.DataView.Contains(StandardDataFormats.Text) ? DataPackageOperation.Copy : DataPackageOperation.None);
        }

        private void Source_DropCompleted(UIElement sender, DropCompletedEventArgs args)
        {
            var listView = sender as ListView;
            if (listView != null)
            {
                dropListView = listView;
                dropCollection = listView.ItemsSource as ObservableCollection<Listview2details>;
                if (dropListView == dragListView)
                {
                    return;
                }
            }
        }
    }


        public class Listview2details
        {
        public string Title { get; set; }
        //public string image { get; set; }
        }
}
