﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Input;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Bezier_Curve_UI
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
       // int val = h7.GetValue(Y1);

        private void MySlider1_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            MyCurve1.Point2 = new Point(150, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve1.Point1 = new Point(50, 1 * (Convert.ToDouble(e.NewValue)));
            Curve2.StartPoint = new Point(150, 1 * (Convert.ToDouble(e.NewValue)));
            h1.Y2 = 250;
            h2.Y2 = 250;
            h3.Y2 = 250;
            h4.Y2 = 250;
            h5.Y2 = 250;
            h6.Y2 = 250;
            h7.Y2 = 250;
            h2.Y1 = (Convert.ToDouble(e.NewValue)) + 34;
            h3.Y1 = (Convert.ToDouble(e.NewValue)) + 16;
            h4.Y1 = (Convert.ToDouble(e.NewValue)) + 10;
            h5.Y1 = (Convert.ToDouble(e.NewValue)) + 5;
            h6.Y1 = (Convert.ToDouble(e.NewValue)) + 1;
            h7.Y1 = (Convert.ToDouble(e.NewValue));
           
            if (Convert.ToDouble(e.NewValue)!= 250)
            {
                h2.Visibility = Visibility;

                h3.Visibility = Visibility;

                h4.Visibility = Visibility;
                h5.Visibility = Visibility;
                h6.Visibility = Visibility;
                h7.Visibility = Visibility;

            }
        }

        private void MySlider2_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
           
            Curve3.StartPoint = new Point(300, 1 * (Convert.ToDouble(e.NewValue)));
            //MyCurve3.Point1 = new Point(350, 1 * ((Convert.ToDouble(e.NewValue)) + 10));

            MyCurve2.Point3 = new Point(300, 1 * (Convert.ToDouble(e.NewValue)));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve2.Point2 = new Point(250, (1 * (Convert.ToDouble(e.NewValue))) - 10);
                MyCurve2.Point1 = new Point(240, -1 * ((Convert.ToDouble(e.NewValue)) - 250));
                MyCurve3.Point1 = new Point(350, 1 * ((Convert.ToDouble(e.NewValue)) + 10));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250) {
                MyCurve2.Point2 = new Point(250, 250);
                MyCurve2.Point1 = new Point(240, 250);
            }   
        }

        private void MySlider3_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            MyCurve3.Point3 = new Point(450, 1 * (Convert.ToDouble(e.NewValue)));
            Curve4.StartPoint = new Point(450, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve4.Point1= new Point(500, 1 * ((Convert.ToDouble(e.NewValue))));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve3.Point2 = new Point(400, 1 * (Convert.ToDouble(e.NewValue)));
            
            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve3.Point2 = new Point(400, 250);
                MyCurve3.Point1 = new Point(350, 250);
            }

        }

        private void MySlider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            //MyCurve4.Point3 = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
            //MyCurve4.Point2 = new Point(500, 1 * ((Convert.ToDouble(e.NewValue))-10));
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve4.Point3 = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
                MyCurve4.Point2 = new Point(500, 1 * ((Convert.ToDouble(e.NewValue)) - 10));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve4.Point3 = new Point(600, 250);
                MyCurve4.Point2 = new Point(500,250);
            }

            Curve5.StartPoint = new Point(600, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve5.Point1 = new Point(660, 1 * (Convert.ToDouble(e.NewValue)));


        }

        private void MySlider5_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            if ((Convert.ToDouble(e.NewValue)) != 250)
            {
                MyCurve5.Point2 = new Point(700, 1 * ((Convert.ToDouble(e.NewValue)) + 10));
                MyCurve5.Point3 = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));

            }
            else if ((Convert.ToDouble(e.NewValue)) == 250)
            {
                MyCurve5.Point2 = new Point(700, 250);
                MyCurve5.Point3 = new Point(750, 250);
            }
            //MyCurve5.Point2 = new Point(700, 1 * ((Convert.ToDouble(e.NewValue))+10));
            //MyCurve5.Point3 = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));
            MyCurve6.Point1 = new Point(810, 1 * (Convert.ToDouble(e.NewValue)));
            Curve6.StartPoint = new Point(750, 1 * (Convert.ToDouble(e.NewValue)));
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            MyCurve1.Point1 = new Point(50, 250);
            MyCurve1.Point2 = new Point(150, 250);
            Curve2.StartPoint = new Point(150, 250);
            MyCurve2.Point1 = new Point(240, 250);
            MyCurve2.Point2 = new Point(250, 250);
            MyCurve2.Point3 = new Point(300, 250);
            Curve3.StartPoint = new Point(300,250);
            MyCurve3.Point1 = new Point(350, 250);
            MyCurve3.Point2 = new Point(400, 250);
            MyCurve3.Point3 = new Point(450, 250);
            Curve4.StartPoint = new Point(450, 250);
            MyCurve4.Point1 = new Point(500, 250);
            MyCurve4.Point2 = new Point(500, 250);
            MyCurve4.Point3 = new Point(600, 250);
            Curve5.StartPoint = new Point(600,250);
            MyCurve5.Point1 = new Point(660,250);
            MyCurve5.Point2 = new Point(700, 250);
            MyCurve5.Point3 = new Point(750, 250);
            Curve6.StartPoint = new Point(750, 250);
            MyCurve6.Point1 = new Point(810, 250);
            MySlider1.Value = 250;
            MySlider2.Value = 250;
            MySlider3.Value = 250;
            MySlider4.Value = 250;
            MySlider5.Value = 250;

        }

        private void MouseValues(object sender, PointerRoutedEventArgs e)
        {
            PointerPoint point = e.GetCurrentPoint(Grid1);

            var x = (Int16)point.Position.X;
            var y = (Int16)point.Position.Y;
            Messagebox.Text = " " + x + "," + y;

        }
    }
}
